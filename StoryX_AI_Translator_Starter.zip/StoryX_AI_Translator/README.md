# StoryX AI Translator — Starter

A beginner prototype for a personal Khmer dubbing workflow.

## What it does
- Accepts an optional source URL for reference.
- Accepts an uploaded video/audio file.
- Extracts audio with FFmpeg.
- Transcribes speech using Faster-Whisper.
- Translates the transcript to Khmer.
- Exports Khmer text and optionally an MP3 voice track.

## Important limitations
- This starter does **not** automatically download videos from YouTube, Facebook, or TikTok.
- It does **not yet** combine the Khmer audio with the original video into a finished MP4.
- Translation and text-to-speech output must be reviewed for accuracy.
- Long videos may exceed free hosting memory/time limits.
- Use only videos you own or have permission to process and republish.

## Deploy from an iPhone
1. Sign in to GitHub in Safari and create a new repository named `storyx-ai-translator`.
2. Upload `app.py`, `requirements.txt`, and `packages.txt` from this folder to the repository.
3. Open Streamlit Community Cloud in Safari and connect the repository.
4. Select `app.py` as the main file and deploy.
5. Test first with a short, rights-cleared MP4 or MP3.

A free hosting tier may have limits or change over time. The first run can take several minutes because the speech model needs to download.

## Local prerequisites (for a computer later)
Python 3.10+ and FFmpeg are required.
