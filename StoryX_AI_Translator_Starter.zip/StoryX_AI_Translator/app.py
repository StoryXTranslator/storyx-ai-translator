import os
import subprocess
import tempfile
from pathlib import Path

import streamlit as st
from deep_translator import GoogleTranslator
from faster_whisper import WhisperModel
from gtts import gTTS

st.set_page_config(page_title="StoryX AI Translator", page_icon="🎬", layout="centered")

st.title("🎬 StoryX AI Translator")
st.caption("គំរូដំបូង៖ បម្លែងសំឡេងក្នុងវីដេអូទៅជាអត្ថបទ បកប្រែជាខ្មែរ និងបង្កើតសំឡេងខ្មែរ")

st.info(
    "កំណែនេះដំណើរការលើម៉ាស៊ីន Cloud ដូចជា Streamlit Community Cloud។ "
    "តំណ YouTube/Facebook/TikTok ត្រូវបានរក្សាទុកជាប្រភពយោងប៉ុណ្ណោះ; "
    "សូម Upload ឯកសារដែលអ្នកមានសិទ្ធិប្រើ។ កំណែនេះមិនទាញយកវីដេអូពីតំណដោយស្វ័យប្រវត្តិទេ។"
)

source_url = st.text_input(
    "តំណប្រភព (ជាជម្រើស)",
    placeholder="https://youtube.com/... ឬ https://www.facebook.com/..."
)
uploaded = st.file_uploader(
    "Upload វីដេអូ ឬឯកសារសំឡេងដែលអ្នកមានសិទ្ធិប្រើ",
    type=["mp4", "mov", "m4v", "webm", "mp3", "wav", "m4a", "aac"]
)

model_size = st.selectbox(
    "គុណភាពស្គាល់សំឡេង (ម៉ូដែលធំអាចយឺតជាង)",
    ["tiny", "base", "small"],
    index=0
)
source_language = st.selectbox(
    "ភាសាសំឡេងដើម",
    ["Auto detect", "Chinese", "English", "Thai", "Vietnamese", "Japanese", "Korean"],
    index=0
)
make_voice = st.checkbox("បង្កើតសំឡេងនិយាយជាភាសាខ្មែរ (MP3)", value=True)

lang_map = {
    "Auto detect": None,
    "Chinese": "zh",
    "English": "en",
    "Thai": "th",
    "Vietnamese": "vi",
    "Japanese": "ja",
    "Korean": "ko",
}

def run_ffmpeg(input_path: str, output_path: str):
    cmd = [
        "ffmpeg", "-y", "-i", input_path, "-vn",
        "-ac", "1", "-ar", "16000", "-b:a", "64k", output_path
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError("មិនអាចដកសំឡេងចេញពីឯកសារបានទេ។ សូមសាកល្បង MP4/MP3 ផ្សេងទៀត។")

def translate_in_chunks(text: str) -> str:
    # Translate smaller chunks to reduce request size. Review the result before publishing.
    translator = GoogleTranslator(source="auto", target="km")
    pieces = []
    words = text.split()
    chunk = []
    for word in words:
        chunk.append(word)
        if len(" ".join(chunk)) >= 900:
            pieces.append(translator.translate(" ".join(chunk)))
            chunk = []
    if chunk:
        pieces.append(translator.translate(" ".join(chunk)))
    return "\n".join(pieces)

if st.button("🚀 ចាប់ផ្តើមបកប្រែ", type="primary", use_container_width=True):
    if not uploaded:
        st.warning("សូម Upload ឯកសារវីដេអូ/សំឡេងជាមុន។ តំណតែមួយមិនទាន់ត្រូវបានដំណើរការក្នុងកំណែគំរូនេះទេ។")
        st.stop()

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        suffix = Path(uploaded.name).suffix or ".mp4"
        input_path = temp_dir / f"source{suffix}"
        audio_path = temp_dir / "audio.wav"
        output_mp3 = temp_dir / "khmer_voice.mp3"

        input_path.write_bytes(uploaded.getvalue())

        try:
            with st.spinner("កំពុងដកសំឡេងពីវីដេអូ..."):
                run_ffmpeg(str(input_path), str(audio_path))

            with st.spinner("កំពុងស្គាល់សំឡេងដើម... (វីដេអូវែងអាចចំណាយពេលយូរ)"):
                model = WhisperModel(model_size, device="cpu", compute_type="int8")
                segments, info = model.transcribe(
                    str(audio_path),
                    language=lang_map[source_language],
                    vad_filter=True
                )
                original_segments = [s.text.strip() for s in segments if s.text.strip()]
                original_text = "\n".join(original_segments)

            if not original_text.strip():
                st.error("មិនបានរកឃើញសំឡេងនិយាយច្បាស់ទេ។ សូមសាកល្បងឯកសារផ្សេង។")
                st.stop()

            st.success(f"ស្គាល់ភាសាសំឡេងបាន៖ {info.language}")
            with st.expander("មើលអត្ថបទសំឡេងដើម"):
                st.text_area("អត្ថបទដើម", original_text, height=220)

            with st.spinner("កំពុងបកប្រែជាភាសាខ្មែរ..."):
                khmer_text = translate_in_chunks(original_text)

            st.subheader("📝 អត្ថបទភាសាខ្មែរ")
            st.text_area("សូមពិនិត្យ និងកែសម្រួលមុនប្រើ", khmer_text, height=300)
            st.download_button(
                "⬇️ ទាញយកអត្ថបទខ្មែរ (.txt)",
                data=khmer_text.encode("utf-8"),
                file_name="storyx_khmer_translation.txt",
                mime="text/plain"
            )

            if make_voice:
                with st.spinner("កំពុងបង្កើតសំឡេងខ្មែរ..."):
                    gTTS(text=khmer_text, lang="km", slow=False).save(str(output_mp3))
                st.subheader("🔊 សំឡេងខ្មែរ")
                st.audio(output_mp3.read_bytes(), format="audio/mp3")
                st.download_button(
                    "⬇️ ទាញយកសំឡេងខ្មែរ (.mp3)",
                    data=output_mp3.read_bytes(),
                    file_name="storyx_khmer_voice.mp3",
                    mime="audio/mpeg"
                )

            st.warning(
                "នេះជាគំរូដំបូង៖ វាបង្កើតអត្ថបទ និង MP3 ដាច់ដោយឡែក មិនទាន់បញ្ចូលសំឡេងថ្មីទៅក្នុងវីដេអូ MP4 ទេ។ "
                "សម្រាប់កំណែបន្ទាប់ ត្រូវបន្ថែមការកាត់ត/បញ្ចូលសំឡេង និងការសម្របពេលវេលា។"
            )
            if source_url.strip():
                st.caption(f"តំណប្រភពដែលបានកត់ត្រា៖ {source_url.strip()}")

        except FileNotFoundError:
            st.error("ម៉ាស៊ីនមិនមាន FFmpeg ទេ។ សូមពិនិត្យ packages.txt និងការដាក់ពង្រាយកម្មវិធី។")
        except Exception as exc:
            st.error(f"មានបញ្ហាក្នុងដំណើរការ៖ {exc}")
            st.caption("សាកល្បងឯកសារខ្លីជាមុន។ កំណែឥតគិតថ្លៃអាចមានកំណត់ពេលវេលា និងអង្គចងចាំ។")

st.divider()
st.caption("StoryX AI Translator · Prototype សម្រាប់ប្រើផ្ទាល់ខ្លួន")
